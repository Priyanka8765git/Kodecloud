What is the subnet mask of the IP Address identified in the previous question (interface eth1)? Save the answer in a new file /home/bob/subnet_mask.

