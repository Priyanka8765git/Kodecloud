Question

Which one of the following operating systems is installed on the student-node? Save the exact answer from the options in a new file /home/bob/host-os

Answer 

CentOS 8
command : cat /etc/os-release

# This command is used to find the Operating system installed in this student-node
# This answer is saved in this file /home/bob/host-os
