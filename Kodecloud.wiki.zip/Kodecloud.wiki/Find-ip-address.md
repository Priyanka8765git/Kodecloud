Question 
What is IP Address assigned to the physical interface eth1? Save the answer in a new file: /home/bob/physical_ipaddress.

Answer
command : ip address show dev eth1
# This command is used to find the ip address of the physical interface
# Answer saved in this file /home/bob/physical_ipaddress.
