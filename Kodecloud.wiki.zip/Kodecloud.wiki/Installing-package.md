Question 


Install the package called util-linux-user on the student-node.
Use sudo if you need to run any command with root level permissions.
Answer : sudo yum install util-linux-user

# This command is used to install package util-linux-user on the student-node.