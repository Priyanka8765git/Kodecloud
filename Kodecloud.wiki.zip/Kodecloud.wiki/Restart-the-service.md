Question 

The student-node server is supposed to run an Apache service. However, it has been configured incorrectly. Fix the issues listed below:
The service is running with user: apache and group: apache
The service should run on port 8081


If the issues are fixed, the application will be accessible by clicking on HTTP Server Test button that is located above the terminal.

Answer : vi /etc/apache/httpd/httpd.conf
 
# Edit this file by changing user: apache and group: apache and port no 8081 and save the file
# restart httpd service 