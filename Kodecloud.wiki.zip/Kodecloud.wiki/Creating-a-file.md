Question 

Add the text KodeKloud Linux Test to a new file called test.txt inside bob's home directory.

Answer : echo "KodeKloud Linux Test" > /home/bob/test.txt

# echo command is used to create a text in a file
