Question 

Find the two files that contain the name prefix large under /var directory and record the filenames in a new file called /opt/largest_files.

Answer 

