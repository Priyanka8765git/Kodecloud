Question 

Identify the package that provides the file /usr/bin/chsh and save the answer in a file called /opt/required_software.
Use sudo if you need to run any command with root level permissions.