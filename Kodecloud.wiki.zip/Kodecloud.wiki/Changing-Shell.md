Question 
Change the default shell for bob from BASH shell to Bourne shell.

Answer : sudo chsh -s /bin/sh bob
 
# This command is used to change the existing shell